import os
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg') # Headless backend for web/server environments
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import tree
import joblib

def generate_all_plots():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, 'dataset', 'loan_credit_risk.csv')
    plots_dir = os.path.join(base_dir, 'static', 'images', 'plots')
    models_dir = os.path.join(base_dir, 'models')
    os.makedirs(plots_dir, exist_ok=True)
    
    # Global visual styling
    plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
    sns.set_palette(['#10b981', '#ef4444', '#3b82f6', '#f59e0b', '#8b5cf6'])
    
    df = pd.read_csv(data_path)
    
    print("\n[1/7] Generating Correlation Heatmap with Seaborn...")
    numeric_cols = [
        'person_age', 'person_income', 'person_emp_length',
        'loan_amnt', 'loan_int_rate', 'loan_percent_income',
        'cb_person_cred_hist_length', 'credit_score', 'loan_status'
    ]
    plt.figure(figsize=(10, 8))
    corr = df[numeric_cols].corr()
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(
        corr, mask=mask, annot=True, fmt='.2f', cmap='coolwarm',
        center=0, square=True, linewidths=.5, cbar_kws={'shrink': .8}
    )
    plt.title('Correlation Matrix of Loan & Borrower Risk Factors', fontsize=14, pad=15, fontweight='bold', color='#1e293b')
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, 'correlation_heatmap.png'), dpi=200)
    plt.close()
    
    print("[2/7] Generating Credit Score Distribution Plot...")
    plt.figure(figsize=(9, 5))
    ax = sns.histplot(
        data=df, x='credit_score', hue='loan_status', kde=True,
        element='step', stat='density', common_norm=False,
        palette={0: '#10b981', 1: '#ef4444'}, bins=30
    )
    plt.title('Credit Score Distribution: Non-Default (0) vs. Default (1)', fontsize=13, fontweight='bold', color='#1e293b')
    plt.xlabel('Credit Score (FICO range 350 - 850)', fontsize=11)
    plt.ylabel('Density', fontsize=11)
    plt.legend(title='Loan Status', labels=['Default (High Risk)', 'Non-Default (Paid)'])
    plt.axvline(x=620, color='#f59e0b', linestyle='--', label='Subprime Cutoff (<620)')
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, 'credit_score_distribution.png'), dpi=200)
    plt.close()
    
    print("[3/7] Generating Default Rate by Intent & Home Ownership...")
    plt.figure(figsize=(10, 5.5))
    intent_home = df.groupby(['loan_intent', 'person_home_ownership'])['loan_status'].mean().reset_index()
    intent_home['default_rate_pct'] = intent_home['loan_status'] * 100
    sns.barplot(
        data=intent_home, x='loan_intent', y='default_rate_pct',
        hue='person_home_ownership', palette='Blues_r'
    )
    plt.title('Default Rate (%) by Loan Intent and Home Ownership Type', fontsize=13, fontweight='bold', color='#1e293b')
    plt.xlabel('Loan Intent Category', fontsize=11)
    plt.ylabel('Observed Default Rate (%)', fontsize=11)
    plt.xticks(rotation=25)
    plt.legend(title='Home Ownership')
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, 'risk_by_intent_and_home.png'), dpi=200)
    plt.close()
    
    print("[4/7] Generating Income vs Loan Amount Scatter...")
    plt.figure(figsize=(9, 5.5))
    sns.scatterplot(
        data=df.sample(min(1200, len(df)), random_state=42),
        x='person_income', y='loan_amnt', hue='loan_status',
        palette={0: '#10b981', 1: '#ef4444'}, alpha=0.7, s=35
    )
    plt.title('Loan Amount vs. Annual Income (Sampled Applicants)', fontsize=13, fontweight='bold', color='#1e293b')
    plt.xlabel('Annual Income ($)', fontsize=11)
    plt.ylabel('Requested Loan Amount ($)', fontsize=11)
    plt.legend(title='Loan Outcome', labels=['Non-Default', 'Default'])
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, 'income_vs_loan_amount.png'), dpi=200)
    plt.close()
    
    print("[5/7] Generating Random Forest Feature Importances...")
    with open(os.path.join(base_dir, 'static', 'data', 'metrics.json'), 'r') as f:
        metrics_data = json.load(f)
    top_features = metrics_data['top_features'][:10]
    
    feat_names = [item['feature'].replace('person_', '').replace('cb_person_', '').replace('loan_', '') for item in top_features]
    feat_scores = [item['importance'] for item in top_features]
    
    plt.figure(figsize=(9, 5.5))
    y_pos = np.arange(len(feat_names))
    plt.barh(y_pos, feat_scores[::-1], color='#3b82f6', edgecolor='#1d4ed8')
    plt.yticks(y_pos, feat_names[::-1], fontsize=10)
    plt.xlabel('Importance Contribution (%)', fontsize=11)
    plt.title('Top 10 Decisive Risk Drivers (Random Forest Gini Importance)', fontsize=13, fontweight='bold', color='#1e293b')
    for i, v in enumerate(feat_scores[::-1]):
        plt.text(v + 0.3, i, f"{v}%", va='center', fontsize=9, fontweight='bold', color='#1e293b')
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, 'feature_importance_rf.png'), dpi=200)
    plt.close()
    
    print("[6/7] Generating Model Evaluation Comparison Chart...")
    models_dict = metrics_data['models']
    model_labels = ['Logistic Regression', 'Decision Tree', 'Random Forest']
    model_keys = ['logistic_regression', 'decision_tree', 'random_forest']
    metrics_names = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC']
    
    comp_data = []
    for mk, ml in zip(model_keys, model_labels):
        m = models_dict[mk]
        comp_data.append({'Model': ml, 'Metric': 'Accuracy', 'Score (%)': m['accuracy']})
        comp_data.append({'Model': ml, 'Metric': 'Precision', 'Score (%)': m['precision']})
        comp_data.append({'Model': ml, 'Metric': 'Recall', 'Score (%)': m['recall']})
        comp_data.append({'Model': ml, 'Metric': 'F1-Score', 'Score (%)': m['f1_score']})
        comp_data.append({'Model': ml, 'Metric': 'ROC-AUC', 'Score (%)': m['roc_auc']})
        
    comp_df = pd.DataFrame(comp_data)
    plt.figure(figsize=(10, 5.5))
    sns.barplot(data=comp_df, x='Metric', y='Score (%)', hue='Model', palette=['#3b82f6', '#10b981', '#8b5cf6'])
    plt.title('Comparative Assessment of ML Classifiers (Baek & Kim Framework)', fontsize=13, fontweight='bold', color='#1e293b')
    plt.ylim(50, 100)
    plt.ylabel('Performance Metric (%)', fontsize=11)
    plt.legend(title='Algorithm', loc='lower right')
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, 'model_performance_comparison.png'), dpi=200)
    plt.close()
    
    print("[7/7] Generating Decision Tree Architecture Visualization...")
    dt_path = os.path.join(models_dir, 'decision_tree.joblib')
    meta_path = os.path.join(models_dir, 'preprocessor_meta.json')
    if os.path.exists(dt_path) and os.path.exists(meta_path):
        dt_model = joblib.load(dt_path)
        with open(meta_path, 'r') as f:
            meta = json.load(f)
        feature_names = meta['feature_cols']
        
        plt.figure(figsize=(18, 9), dpi=250)
        tree.plot_tree(
            dt_model,
            max_depth=3, # Show top 3 levels for clean clarity
            feature_names=feature_names,
            class_names=['Paid (0)', 'Default (1)'],
            filled=True,
            rounded=True,
            fontsize=8,
            precision=2
        )
        plt.title('Finsight Decision Tree - Non-Linear Decision Thresholds (Top 3 Depths)', fontsize=14, fontweight='bold', pad=12)
        plt.tight_layout()
        plt.savefig(os.path.join(plots_dir, 'decision_tree_structure.png'), dpi=250)
        plt.close()
        
    print("All 7 Matplotlib & Seaborn visualizations generated successfully!")

if __name__ == '__main__':
    generate_all_plots()
