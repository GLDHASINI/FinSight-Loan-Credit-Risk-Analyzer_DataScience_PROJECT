import os
import json
import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report
)

def run_ml_pipeline():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_path = os.path.join(base_dir, 'dataset', 'loan_credit_risk.csv')
    models_dir = os.path.join(base_dir, 'models')
    static_data_dir = os.path.join(base_dir, 'static', 'data')
    os.makedirs(models_dir, exist_ok=True)
    os.makedirs(static_data_dir, exist_ok=True)
    
    print("="*60)
    print("FINSIGHT - LOAN/CREDIT RISK ML PIPELINE")
    print("="*60)
    
    # 1. Load Data
    df = pd.read_csv(data_path)
    print(f"Loaded dataset: {df.shape[0]} rows, {df.shape[1]} columns")
    
    # Save a clean sample for frontend inspection
    sample_data = df.head(10).to_dict(orient='records')
    with open(os.path.join(static_data_dir, 'dataset_sample.json'), 'w') as f:
        json.dump(sample_data, f, indent=2)
        
    # 2. Preprocessing & Imputation
    # Store medians for production inference pipeline
    emp_median = float(df['person_emp_length'].median())
    rate_median = float(df['loan_int_rate'].median())
    
    df_clean = df.copy()
    df_clean['person_emp_length'] = df_clean['person_emp_length'].fillna(emp_median)
    df_clean['loan_int_rate'] = df_clean['loan_int_rate'].fillna(rate_median)
    
    # 3. Feature Selection & Encoding
    categorical_cols = ['person_home_ownership', 'loan_intent', 'loan_grade', 'cb_person_default_on_file']
    numeric_cols = [
        'person_age', 'person_income', 'person_emp_length',
        'loan_amnt', 'loan_int_rate', 'loan_percent_income',
        'cb_person_cred_hist_length', 'credit_score'
    ]
    
    # One-Hot Encoding
    df_encoded = pd.get_dummies(df_clean, columns=categorical_cols, drop_first=False)
    
    feature_cols = [c for c in df_encoded.columns if c != 'loan_status']
    X = df_encoded[feature_cols]
    y = df_encoded['loan_status']
    
    # 4. Train-Test Split (80/20 stratified)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    print(f"Train set: {X_train.shape[0]} samples | Test set: {X_test.shape[0]} samples")
    
    # Feature Scaling (Fit on train, transform test)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # 5. Train Models (as outlined in PPT: Logistic Regression, Decision Tree, Random Forest)
    print("\nTraining models...")
    
    # 5a. Logistic Regression
    lr_model = LogisticRegression(max_iter=1000, random_state=42)
    lr_model.fit(X_train_scaled, y_train)
    
    # 5b. Decision Tree
    dt_model = DecisionTreeClassifier(max_depth=5, min_samples_split=10, random_state=42)
    dt_model.fit(X_train, y_train) # Tree models don't require scaled inputs
    
    # 5c. Random Forest
    rf_model = RandomForestClassifier(n_estimators=120, max_depth=10, min_samples_split=8, random_state=42)
    rf_model.fit(X_train, y_train)
    
    models = {
        'logistic_regression': {
            'name': 'Logistic Regression',
            'model': lr_model,
            'uses_scaled': True,
            'desc': 'Linear probabilistic baseline using Sigmoid function; interprets overall odds ratio and feature weights.'
        },
        'decision_tree': {
            'name': 'Decision Tree Classifier',
            'model': dt_model,
            'uses_scaled': False,
            'desc': 'Hierarchical rule-based tree model using recursive Gini impurity splits; captures non-linear thresholds.'
        },
        'random_forest': {
            'name': 'Random Forest Classifier',
            'model': rf_model,
            'uses_scaled': False,
            'desc': 'Ensemble bagging algorithm combining 120 decision trees with feature sub-sampling to maximize stability and accuracy.'
        }
    }
    
    # 6. Evaluation & Comparison Metrics
    evaluation_results = {}
    
    for key, item in models.items():
        clf = item['model']
        test_features = X_test_scaled if item['uses_scaled'] else X_test
        
        y_pred = clf.predict(test_features)
        y_prob = clf.predict_proba(test_features)[:, 1]
        
        acc = float(accuracy_score(y_test, y_pred))
        prec = float(precision_score(y_test, y_pred))
        rec = float(recall_score(y_test, y_pred))
        f1 = float(f1_score(y_test, y_pred))
        auc = float(roc_auc_score(y_test, y_prob))
        cm = confusion_matrix(y_test, y_pred).tolist()
        
        evaluation_results[key] = {
            'id': key,
            'name': item['name'],
            'description': item['desc'],
            'accuracy': round(acc * 100, 2),
            'precision': round(prec * 100, 2),
            'recall': round(rec * 100, 2),
            'f1_score': round(f1 * 100, 2),
            'roc_auc': round(auc * 100, 2),
            'confusion_matrix': {
                'tn': cm[0][0],
                'fp': cm[0][1],
                'fn': cm[1][0],
                'tp': cm[1][1]
            }
        }
        print(f"[{item['name']}] Acc: {acc*100:.2f}% | Prec: {prec*100:.2f}% | Rec: {rec*100:.2f}% | F1: {f1*100:.2f}% | AUC: {auc*100:.2f}%")
        
        # Save individual model file
        model_filename = os.path.join(models_dir, f"{key}.joblib")
        joblib.dump(clf, model_filename)
        print(f"  -> Model saved to: {model_filename}")
        
    # 7. Extract Feature Importances (Random Forest)
    importances = rf_model.feature_importances_
    feat_imp = sorted(zip(feature_cols, importances), key=lambda x: x[1], reverse=True)
    top_features = [{'feature': f, 'importance': round(float(imp) * 100, 2)} for f, imp in feat_imp[:12]]
    
    # 8. Save Preprocessor & Metadata Pipeline
    preprocessor_meta = {
        'numeric_cols': numeric_cols,
        'categorical_cols': categorical_cols,
        'feature_cols': feature_cols,
        'emp_median': emp_median,
        'rate_median': rate_median,
        'home_ownership_options': sorted(df['person_home_ownership'].unique().tolist()),
        'loan_intent_options': sorted(df['loan_intent'].unique().tolist()),
        'loan_grade_options': sorted(df['loan_grade'].unique().tolist()),
        'default_on_file_options': ['N', 'Y'],
        'top_feature_importances': top_features,
        'dataset_summary': {
            'total_records': len(df),
            'train_records': len(X_train),
            'test_records': len(X_test),
            'default_rate_pct': round(float(df['loan_status'].mean() * 100), 2),
            'non_default_count': int((df['loan_status'] == 0).sum()),
            'default_count': int((df['loan_status'] == 1).sum()),
            'features_count': len(feature_cols)
        }
    }
    
    joblib.dump(scaler, os.path.join(models_dir, 'scaler.joblib'))
    with open(os.path.join(models_dir, 'preprocessor_meta.json'), 'w') as f:
        json.dump(preprocessor_meta, f, indent=2)
        
    with open(os.path.join(static_data_dir, 'metrics.json'), 'w') as f:
        json.dump({
            'models': evaluation_results,
            'summary': preprocessor_meta['dataset_summary'],
            'top_features': top_features
        }, f, indent=2)
        
    print("\nSuccessfully completed ML Pipeline! All models, scalers, and metrics exported.")
    return evaluation_results

if __name__ == '__main__':
    run_ml_pipeline()
