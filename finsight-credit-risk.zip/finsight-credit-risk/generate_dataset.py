import numpy as np
import pandas as pd
import os

def generate_credit_dataset(num_records=5000, random_seed=42):
    np.random.seed(random_seed)
    
    # Age: skewed normal between 21 and 65
    age = np.random.normal(32, 8, num_records).astype(int)
    age = np.clip(age, 20, 68)
    
    # Employment length correlated slightly with age
    emp_length = np.clip(np.random.normal((age - 18) * 0.35, 3, num_records), 0, 30).round(1)
    # Introduce ~3% realistic missing values
    emp_nan_idx = np.random.choice(num_records, size=int(num_records * 0.03), replace=False)
    emp_length[emp_nan_idx] = np.nan
    
    # Annual Income (log-normal distribution)
    income = np.random.lognormal(mean=10.9, sigma=0.6, size=num_records).astype(int)
    income = np.clip(income, 14000, 260000)
    
    # Home ownership
    home_options = ['RENT', 'MORTGAGE', 'OWN', 'OTHER']
    home_probs = [0.50, 0.40, 0.08, 0.02]
    home_ownership = np.random.choice(home_options, size=num_records, p=home_probs)
    
    # Loan Intent
    intent_options = ['EDUCATION', 'MEDICAL', 'VENTURE', 'PERSONAL', 'DEBTCONSOLIDATION', 'HOMEIMPROVEMENT']
    intent_probs = [0.22, 0.20, 0.18, 0.16, 0.14, 0.10]
    loan_intent = np.random.choice(intent_options, size=num_records, p=intent_probs)
    
    # Credit Score (300 to 850, centered around 660)
    credit_score = np.random.normal(655, 65, num_records).astype(int)
    credit_score = np.clip(credit_score, 350, 840)
    
    # Historical default on file (more likely if low credit score)
    def_prob = np.where(credit_score < 580, 0.45, np.where(credit_score < 680, 0.15, 0.03))
    default_on_file = np.where(np.random.rand(num_records) < def_prob, 'Y', 'N')
    
    # Loan Amount (correlated with income)
    loan_amnt = (np.random.uniform(0.08, 0.38, num_records) * income).astype(int)
    loan_amnt = np.clip(loan_amnt, 1500, 35000)
    
    # Loan percent of income
    loan_percent_income = np.round(loan_amnt / income, 2)
    
    # Loan Grade & Interest rate
    # Grade determined by credit score & DTI
    grade_score = credit_score - (loan_percent_income * 250)
    loan_grade = np.empty(num_records, dtype=object)
    loan_grade[grade_score >= 680] = 'A'
    loan_grade[(grade_score >= 620) & (grade_score < 680)] = 'B'
    loan_grade[(grade_score >= 560) & (grade_score < 620)] = 'C'
    loan_grade[(grade_score >= 500) & (grade_score < 560)] = 'D'
    loan_grade[(grade_score >= 440) & (grade_score < 500)] = 'E'
    loan_grade[grade_score < 440] = 'F'
    
    base_rate_map = {'A': 7.2, 'B': 10.5, 'C': 13.4, 'D': 16.2, 'E': 18.8, 'F': 21.5}
    base_rates = np.array([base_rate_map[g] for g in loan_grade])
    loan_int_rate = np.round(base_rates + np.random.normal(0, 1.2, num_records), 2)
    loan_int_rate = np.clip(loan_int_rate, 5.0, 24.5)
    # Introduce ~3.5% realistic missing values
    rate_nan_idx = np.random.choice(num_records, size=int(num_records * 0.035), replace=False)
    loan_int_rate[rate_nan_idx] = np.nan
    
    # Credit History Length (in years, correlated with age)
    cred_hist_length = np.clip(np.random.normal((age - 19) * 0.38, 2, num_records), 1, 28).astype(int)
    
    # Target: Loan Status (0 = Non-Default, 1 = Default)
    # Logit formula: heavily driven by DTI, credit score, interest rate, past default
    z = (
        - 0.012 * (credit_score - 600)
        + 5.5 * (loan_percent_income - 0.20)
        + 0.14 * (np.nan_to_num(loan_int_rate, nan=12.5) - 11.0)
        + 1.8 * (default_on_file == 'Y')
        + 0.35 * (home_ownership == 'RENT')
        - 0.45 * (home_ownership == 'OWN')
        - 0.8  # baseline offset
    )
    # Sigmoid function
    default_probability = 1 / (1 + np.exp(-z))
    loan_status = (np.random.rand(num_records) < default_probability).astype(int)
    
    df = pd.DataFrame({
        'person_age': age,
        'person_income': income,
        'person_home_ownership': home_ownership,
        'person_emp_length': emp_length,
        'loan_intent': loan_intent,
        'loan_grade': loan_grade,
        'loan_amnt': loan_amnt,
        'loan_int_rate': loan_int_rate,
        'loan_percent_income': loan_percent_income,
        'cb_person_default_on_file': default_on_file,
        'cb_person_cred_hist_length': cred_hist_length,
        'credit_score': credit_score,
        'loan_status': loan_status
    })
    
    output_path = os.path.join(os.path.dirname(__file__), 'dataset', 'loan_credit_risk.csv')
    df.to_csv(output_path, index=False)
    print(f"Generated realistic loan dataset with {num_records} rows at: {output_path}")
    print(f"Default rate: {df['loan_status'].mean()*100:.2f}%")
    print(f"Missing values in person_emp_length: {df['person_emp_length'].isna().sum()}")
    print(f"Missing values in loan_int_rate: {df['loan_int_rate'].isna().sum()}")
    return output_path

if __name__ == '__main__':
    generate_credit_dataset()
