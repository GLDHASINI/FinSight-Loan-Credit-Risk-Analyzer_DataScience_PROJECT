/**
 * FINSIGHT - INTELLIGENT CREDIT & LOAN RISK PLATFORM
 * Dual-Role (Lender / Borrower) Frontend Logic
 */

let CURRENT_ROLE = 'lender'; // 'lender' or 'borrower'
let ALL_APPLICATIONS = [];
let ACTIVE_APPLICANT = null;

document.addEventListener('DOMContentLoaded', () => {
    initTabNavigation();
    initBorrowerForm();
    loadApplicationsTable();
    computeStandaloneEmi();
    updateBorrowerPreview();
});

/* ========================================================
   1. ROLE SWITCHING & AUTHENTICATION
   ======================================================== */
window.selectRole = function(role) {
    CURRENT_ROLE = role;
    closeLoginModal();

    const body = document.body;
    const lenderNav = document.getElementById('lender-nav-group');
    const borrowerNav = document.getElementById('borrower-nav-group');
    const roleLabel = document.getElementById('current-role-label');
    const switchTargetText = document.getElementById('switch-target-text');

    if (role === 'lender') {
        body.classList.remove('role-borrower');
        body.classList.add('role-lender');
        lenderNav.style.display = 'flex';
        borrowerNav.style.display = 'none';
        roleLabel.innerHTML = 'Active Mode: <strong>Loan Giver (Lender)</strong>';
        switchTargetText.textContent = 'Loan Borrower';

        // Activate first lender tab
        switchTab('tab-lender-queue');
        loadApplicationsTable();
    } else {
        body.classList.remove('role-lender');
        body.classList.add('role-borrower');
        lenderNav.style.display = 'none';
        borrowerNav.style.display = 'flex';
        roleLabel.innerHTML = 'Active Mode: <strong>Loan Borrower (Applicant)</strong>';
        switchTargetText.textContent = 'Loan Giver';

        // Activate first borrower tab
        switchTab('tab-borrower-apply');
        loadBorrowerStatusTable();
    }
};

window.toggleRole = function() {
    selectRole(CURRENT_ROLE === 'lender' ? 'borrower' : 'lender');
};

window.openLoginModal = function() {
    const modal = document.getElementById('login-modal');
    if (modal) modal.classList.add('open');
};

window.closeLoginModal = function() {
    const modal = document.getElementById('login-modal');
    if (modal) modal.classList.remove('open');
};

/* ========================================================
   2. TAB NAVIGATION
   ======================================================== */
function initTabNavigation() {
    const navTabs = document.querySelectorAll('.nav-tab');
    navTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetId = tab.getAttribute('data-tab');
            switchTab(targetId);
        });
    });
}

function switchTab(tabId) {
    const activeNavGroup = CURRENT_ROLE === 'lender' 
        ? document.getElementById('lender-nav-group') 
        : document.getElementById('borrower-nav-group');

    // Deactivate tabs in current group
    activeNavGroup.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
    
    // Hide all panes
    document.querySelectorAll('.tab-pane').forEach(p => {
        p.classList.remove('active');
        p.style.display = 'none';
    });

    // Activate selected tab & pane
    const activeBtn = activeNavGroup.querySelector(`[data-tab="${tabId}"]`);
    if (activeBtn) activeBtn.classList.add('active');

    const targetPane = document.getElementById(tabId);
    if (targetPane) {
        targetPane.classList.add('active');
        targetPane.style.display = 'block';
    }
}

/* ========================================================
   3. LENDER: APPLICATIONS QUEUE & EVALUATION
   ======================================================== */
async function loadApplicationsTable() {
    try {
        const res = await fetch('/api/applications');
        ALL_APPLICATIONS = await res.json();

        const tbody = document.getElementById('lender-queue-tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        if (ALL_APPLICATIONS.length === 0) {
            tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;">No loan applications in queue.</td></tr>';
            return;
        }

        // Set default active applicant if none selected
        if (!ACTIVE_APPLICANT) {
            ACTIVE_APPLICANT = ALL_APPLICATIONS[0];
            populateUnderwriterDesk(ACTIVE_APPLICANT);
        }

        ALL_APPLICATIONS.forEach(app => {
            const tr = document.createElement('tr');
            const dti = ((app.loan_amnt / Math.max(app.person_income, 1)) * 100).toFixed(1);
            
            let statusBadge = '<span class="status-badge status-pending"><i class="fa-solid fa-clock"></i> Pending Review</span>';
            if (app.status === 'Approved') {
                statusBadge = '<span class="status-badge status-approved"><i class="fa-solid fa-check"></i> Approved</span>';
            } else if (app.status === 'Conditional') {
                statusBadge = '<span class="status-badge status-conditional"><i class="fa-solid fa-triangle-exclamation"></i> Conditional</span>';
            } else if (app.status === 'Declined') {
                statusBadge = '<span class="status-badge status-declined"><i class="fa-solid fa-xmark"></i> Declined</span>';
            }

            const termsTag = app.terms_accepted 
                ? '<span style="color:#10b981; font-weight:700;"><i class="fa-solid fa-circle-check"></i> Accepted</span>' 
                : '<span style="color:#ef4444;">Not Accepted</span>';

            tr.innerHTML = `
                <td><strong>${app.id}</strong></td>
                <td><strong>${app.applicant_name}</strong></td>
                <td>$${Number(app.loan_amnt).toLocaleString()}</td>
                <td>$${Number(app.person_income).toLocaleString()}</td>
                <td><strong>${dti}%</strong></td>
                <td><span style="font-family:var(--font-mono); font-weight:700;">${app.credit_score}</span></td>
                <td>${app.loan_intent}</td>
                <td>${termsTag}</td>
                <td>${statusBadge}</td>
                <td>
                    <button class="btn btn-primary btn-sm" onclick="selectApplicantForEval('${app.id}')">
                        <i class="fa-solid fa-microchip"></i> Evaluate
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });

    } catch (err) {
        console.error('Error loading applications:', err);
    }
}

window.selectApplicantForEval = function(appId) {
    const found = ALL_APPLICATIONS.find(a => a.id === appId);
    if (!found) return;

    ACTIVE_APPLICANT = found;
    populateUnderwriterDesk(ACTIVE_APPLICANT);
    switchTab('tab-lender-eval');
    runLenderAssessment();
};

function populateUnderwriterDesk(app) {
    if (!app) return;

    document.getElementById('eval-applicant-label').textContent = `${app.applicant_name} (${app.id})`;
    document.getElementById('eval-app-id-tag').textContent = app.id;
    document.getElementById('eval-loan-amnt').textContent = `$${Number(app.loan_amnt).toLocaleString()}`;
    document.getElementById('eval-income').textContent = `$${Number(app.person_income).toLocaleString()}`;
    
    const dti = ((app.loan_amnt / Math.max(app.person_income, 1)) * 100).toFixed(1);
    document.getElementById('eval-dti').textContent = `${dti}%`;
    document.getElementById('eval-credit-score').textContent = app.credit_score;

    // Pre-populate approved rate suggestion
    document.getElementById('approved-rate-input').value = app.approved_rate || (app.loan_int_rate || 8.5);

    // Verification descriptions
    document.getElementById('chk-score-desc').textContent = `FICO ${app.credit_score} &mdash; ${app.credit_score >= 680 ? 'Meets Tier 1 Prime threshold (>=680).' : 'Subprime range (<680), requires collateral.'}`;
    document.getElementById('chk-dti-desc').textContent = `DTI ${dti}% &mdash; ${dti <= 35 ? 'Comfortable capacity (<35%).' : 'Elevated debt burden (>35%).'}`;
    document.getElementById('chk-default-desc').textContent = app.cb_person_default_on_file === 'Y' ? 'Adverse historical default flag detected.' : 'Clean credit history without recorded defaults.';
}

window.runLenderAssessment = async function() {
    if (!ACTIVE_APPLICANT) return;

    const modelChoice = document.getElementById('lender-model-choice').value;
    const modelBadge = document.getElementById('lender-model-badge');
    const selText = document.getElementById('lender-model-choice').options[document.getElementById('lender-model-choice').selectedIndex].text;
    modelBadge.textContent = selText.split('(')[0].trim();

    try {
        const payload = {
            model_type: modelChoice,
            person_age: ACTIVE_APPLICANT.person_age,
            person_income: ACTIVE_APPLICANT.person_income,
            person_emp_length: ACTIVE_APPLICANT.person_emp_length,
            person_home_ownership: ACTIVE_APPLICANT.person_home_ownership,
            loan_amnt: ACTIVE_APPLICANT.loan_amnt,
            loan_intent: ACTIVE_APPLICANT.loan_intent,
            loan_grade: ACTIVE_APPLICANT.loan_grade,
            loan_int_rate: ACTIVE_APPLICANT.loan_int_rate,
            cb_person_default_on_file: ACTIVE_APPLICANT.cb_person_default_on_file,
            cb_person_cred_hist_length: ACTIVE_APPLICANT.cb_person_cred_hist_length,
            credit_score: ACTIVE_APPLICANT.credit_score
        };

        const res = await fetch('/api/predict', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await res.json();
        if (data.success) {
            // Update UI elements
            const badge = document.getElementById('lender-risk-badge');
            badge.className = `risk-badge ${data.badge_class}`;
            badge.textContent = data.risk_category;

            document.getElementById('lender-prob-val').textContent = `${data.default_probability}%`;

            const fillBar = document.getElementById('lender-prob-fill');
            fillBar.style.width = `${Math.min(data.default_probability, 100)}%`;
            fillBar.className = `prob-fill ${data.badge_class.replace('badge-', 'bg-')}`;

            document.getElementById('lender-rec-title').textContent = data.recommendation;
            document.getElementById('lender-rec-desc').textContent = data.action_plan;

            // Suggest rate
            if (!ACTIVE_APPLICANT.approved_rate) {
                document.getElementById('approved-rate-input').value = data.suggested_rate;
            }
        }
    } catch (e) {
        console.error('Error running assessment:', e);
    }
};

window.submitLenderDecision = async function() {
    if (!ACTIVE_APPLICANT) return;

    const decision = document.getElementById('decision-action-select').value;
    const rate = document.getElementById('approved-rate-input').value;
    const notes = document.getElementById('lender-notes-input').value;

    try {
        const res = await fetch(`/api/applications/${ACTIVE_APPLICANT.id}/decision`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                decision: decision,
                approved_rate: rate,
                notes: notes
            })
        });

        const data = await res.json();
        if (data.success) {
            alert(`Application ${ACTIVE_APPLICANT.id} status updated to: ${decision}`);
            await loadApplicationsTable();
            switchTab('tab-lender-queue');
        } else {
            alert('Failed to update decision: ' + data.error);
        }
    } catch (err) {
        console.error('Error saving decision:', err);
    }
};

/* ========================================================
   4. BORROWER: APPLY FOR A LOAN WITH TERMS AGREEMENT
   ======================================================== */
function initBorrowerForm() {
    const form = document.getElementById('borrower-loan-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const termsCheckbox = document.getElementById('b-terms-checkbox');
        if (!termsCheckbox.checked) {
            alert('Please review and check the Lender Terms & Conditions agreement before submitting.');
            return;
        }

        const btnSubmit = document.getElementById('btn-submit-borrower-app');
        btnSubmit.disabled = true;
        btnSubmit.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Submitting to Underwriting...';

        const payload = {
            applicant_name: document.getElementById('b-name').value,
            email: document.getElementById('b-email').value,
            person_age: parseInt(document.getElementById('b-age').value),
            person_income: parseFloat(document.getElementById('b-income').value),
            loan_amnt: parseFloat(document.getElementById('b-loan-amnt').value),
            loan_intent: document.getElementById('b-intent').value,
            person_emp_length: parseFloat(document.getElementById('b-emp-length').value),
            person_home_ownership: document.getElementById('b-home').value,
            credit_score: parseInt(document.getElementById('b-credit-score').value),
            cb_person_default_on_file: document.getElementById('b-default-record').value,
            terms_accepted: true
        };

        try {
            const res = await fetch('/api/applications', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const data = await res.json();
            if (data.success) {
                alert('Loan Application submitted successfully! The lender has received your request.');
                form.reset();
                termsCheckbox.checked = false;
                toggleSubmitButton();
                await loadBorrowerStatusTable();
                switchTab('tab-borrower-status');
            } else {
                alert('Submission error: ' + data.error);
            }
        } catch (err) {
            console.error('Error submitting application:', err);
            alert('Failed to submit application.');
        } finally {
            btnSubmit.disabled = false;
            btnSubmit.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Submit Application to Lender';
        }
    });
}

window.toggleSubmitButton = function() {
    const chk = document.getElementById('b-terms-checkbox');
    const btn = document.getElementById('btn-submit-borrower-app');
    if (chk && btn) {
        btn.disabled = !chk.checked;
    }
};

window.updateBorrowerPreview = function() {
    const income = parseFloat(document.getElementById('b-income')?.value || 50000);
    const loan = parseFloat(document.getElementById('b-loan-amnt')?.value || 10000);
    const score = parseInt(document.getElementById('b-credit-score')?.value || 650);

    // Calculate DTI
    const dti = ((loan / Math.max(income, 1)) * 100).toFixed(1);
    const dtiElem = document.getElementById('preview-dti');
    if (dtiElem) {
        dtiElem.textContent = `${dti}%`;
        dtiElem.className = dti > 35 ? 'calc-val text-red' : 'calc-val text-green';
    }

    // Estimate rate based on score
    let estRate = 12.5;
    if (score >= 740) estRate = 7.2;
    else if (score >= 680) estRate = 9.5;
    else if (score >= 600) estRate = 13.8;
    else estRate = 18.5;

    const rateElem = document.getElementById('preview-rate');
    if (rateElem) rateElem.textContent = `${estRate.toFixed(1)}%`;

    // 36 months monthly payment estimate
    const monthlyRate = (estRate / 100) / 12;
    const n = 36;
    const emi = (loan * monthlyRate * Math.pow(1 + monthlyRate, n)) / (Math.pow(1 + monthlyRate, n) - 1);
    const emiElem = document.getElementById('preview-emi');
    if (emiElem) emiElem.textContent = `$${Math.round(emi)} / mo`;
};

async function loadBorrowerStatusTable() {
    try {
        const res = await fetch('/api/applications');
        const apps = await res.json();
        const tbody = document.getElementById('borrower-status-tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        if (apps.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;">No applications submitted yet.</td></tr>';
            return;
        }

        apps.forEach(app => {
            const tr = document.createElement('tr');
            let decisionBadge = '<span class="status-badge status-pending"><i class="fa-solid fa-clock"></i> In Underwriting Review</span>';
            if (app.status === 'Approved') {
                decisionBadge = '<span class="status-badge status-approved"><i class="fa-solid fa-circle-check"></i> Approved</span>';
            } else if (app.status === 'Conditional') {
                decisionBadge = '<span class="status-badge status-conditional"><i class="fa-solid fa-triangle-exclamation"></i> Action Required (Co-Signer)</span>';
            } else if (app.status === 'Declined') {
                decisionBadge = '<span class="status-badge status-declined"><i class="fa-solid fa-circle-xmark"></i> Declined</span>';
            }

            tr.innerHTML = `
                <td><strong>${app.id}</strong></td>
                <td>${app.applicant_name}</td>
                <td><strong>$${Number(app.loan_amnt).toLocaleString()}</strong></td>
                <td>${app.loan_intent}</td>
                <td>${app.submitted_at}</td>
                <td><span style="color:#10b981;"><i class="fa-solid fa-check-double"></i> Accepted on ${app.terms_accepted_at || 'Submission'}</span></td>
                <td>${decisionBadge}</td>
                <td>${app.approved_rate ? '<strong>' + app.approved_rate + '%</strong>' : '<em>Pending</em>'}</td>
                <td>${app.lender_notes || '<em>Awaiting underwriter review</em>'}</td>
            `;
            tbody.appendChild(tr);
        });

    } catch (e) {
        console.error('Error loading borrower status:', e);
    }
}

/* ========================================================
   5. STANDALONE EMI CALCULATOR SLIDERS
   ======================================================== */
window.computeStandaloneEmi = function() {
    const loan = parseFloat(document.getElementById('calc-loan').value);
    const tenure = parseInt(document.getElementById('calc-tenure').value);
    const rate = parseFloat(document.getElementById('calc-interest').value);

    document.getElementById('calc-loan-val').textContent = `$${loan.toLocaleString()}`;
    document.getElementById('calc-tenure-val').textContent = `${tenure} Months`;
    document.getElementById('calc-interest-val').textContent = `${rate.toFixed(1)}%`;

    const monthlyRate = (rate / 100) / 12;
    const emi = (loan * monthlyRate * Math.pow(1 + monthlyRate, tenure)) / (Math.pow(1 + monthlyRate, tenure) - 1);
    const totalAmount = emi * tenure;
    const totalInterest = totalAmount - loan;

    document.getElementById('standalone-emi-val').textContent = `$${Math.round(emi)}`;
    document.getElementById('standalone-principal').textContent = `$${loan.toLocaleString()}`;
    document.getElementById('standalone-interest').textContent = `$${Math.round(totalInterest).toLocaleString()}`;
    document.getElementById('standalone-total').textContent = `$${Math.round(totalAmount).toLocaleString()}`;
};

/* ========================================================
   6. IMAGE MODAL ZOOM
   ======================================================== */
window.openImageModal = function(src) {
    const modal = document.getElementById('image-modal');
    const modalImg = document.getElementById('modal-img');
    if (modal && modalImg) {
        modalImg.src = src;
        modal.classList.add('open');
    }
};

window.closeImageModal = function() {
    const modal = document.getElementById('image-modal');
    if (modal) modal.classList.remove('open');
};

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeImageModal();
        closeLoginModal();
    }
});
