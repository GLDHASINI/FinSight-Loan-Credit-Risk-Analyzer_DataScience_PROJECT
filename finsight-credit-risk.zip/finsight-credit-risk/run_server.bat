@echo off
echo ========================================================
echo Starting Finsight - Loan / Credit Risk Analyzer Dashboard
echo KLH Deemed to be University - DS Project Review-3
echo ========================================================
cd /d "%~dp0"
echo.
echo Launching Flask Web Server...
start "" http://127.0.0.1:5000/
py app.py
pause
