# Finsight – Intelligent Credit & Loan Risk Platform

An enterprise Data Science and Machine Learning web application designed to evaluate loan applications, predict default probability, and categorize borrower credit risk tiers (**Low Risk**, **Medium Risk**, **High Risk**).

---

## 🚀 Key Features

### 1. Dual-Role Experience & Instant Presentation Accounts
- **💼 Loan Giver (Lender / Underwriting Officer)**:
  - **Incoming Applications Queue:** Inspect loan requests submitted by borrowers.
  - **Scikit-learn Underwriting Risk Engine:** Run applicant profiles against **Random Forest**, **Decision Tree**, or **Logistic Regression** classifiers.
  - **Pre-Approval Checklist:** Verify FICO credit score, calculated Debt-to-Income (DTI), past public default history, and terms acceptance.
  - **Lender Decision & Terms Console:** Customize approved interest rate spread, issue official decisions (**Approve**, **Conditional**, **Decline**), and record notes.
  - **Model Benchmark & Portfolio Analytics:** Full access to multi-metric classifier comparisons and Seaborn/Matplotlib exploratory plots.

- **👤 Loan Borrower (Loan Taker / Applicant)**:
  - **Loan Application Form:** Enter desired loan amount, purpose (Education, Medical, Business Venture, Personal), annual income, and employment details.
  - **Live EMI & Affordability Preview:** Instant calculation of monthly payment (EMI) and DTI margin.
  - **Mandatory Lender Terms & Conditions Agreement:** Borrowers must read and check acceptance of the 4-clause legal/lending terms agreement before submission.
  - **Live Application Status Tracker:** Track underwriting review state, approved interest rate, and lender notes in real time.

---

## 🛠️ Data Science & ML Technologies
- **Python 3**
- **Pandas & NumPy:** Missing value imputation (median for employment length & interest rate), one-hot encoding, and feature scaling.
- **Scikit-learn:**
  - **Logistic Regression:** Sigmoid probability baseline.
  - **Decision Tree Classifier:** Recursive Gini impurity splits.
  - **Random Forest Classifier:** 120-estimator ensemble bagging and Gini feature importance ranking.
- **Matplotlib & Seaborn:** 7 dynamic exploratory and benchmark visual charts.
- **Flask:** Lightweight, responsive REST API & web dashboard.

---

## 🏃 Quick Start

### 1-Click Launch (Windows)
Double-click `run_server.bat` in this folder.

### Command Line
```powershell
cd C:\Users\Admin\.gemini\antigravity\scratch\finsight-credit-risk
py app.py
```
Open your browser at:
`http://127.0.0.1:5000/`

---

## 🔑 Demo Presentation Logins
- **Loan Giver:** `underwriter@finsight.com` (or click *"Enter as Loan Giver"*)
- **Loan Borrower:** `borrower@finsight.com` (or click *"Enter as Loan Borrower"*)
*(You can also use the **"Switch Role"** button in the top navigation bar to toggle between perspectives instantly during demonstrations).*
