import os
import json
import uuid
from datetime import datetime
import joblib
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify, session

app = Flask(__name__)
app.secret_key = "finsight_enterprise_risk_token_key_2026"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, 'models')
STATIC_DATA_DIR = os.path.join(BASE_DIR, 'static', 'data')
APPS_FILE = os.path.join(STATIC_DATA_DIR, 'applications.json')

# Load Preprocessor Metadata
meta_path = os.path.join(MODELS_DIR, 'preprocessor_meta.json')
with open(meta_path, 'r') as f:
    PREPROCESSOR_META = json.load(f)

# Load Scaler
SCALER = joblib.load(os.path.join(MODELS_DIR, 'scaler.joblib'))

# Load Models
MODELS = {
    'logistic_regression': joblib.load(os.path.join(MODELS_DIR, 'logistic_regression.joblib')),
    'decision_tree': joblib.load(os.path.join(MODELS_DIR, 'decision_tree.joblib')),
    'random_forest': joblib.load(os.path.join(MODELS_DIR, 'random_forest.joblib'))
}

# Load Metrics
metrics_path = os.path.join(STATIC_DATA_DIR, 'metrics.json')
with open(metrics_path, 'r') as f:
    METRICS_DATA = json.load(f)

def init_applications_store():
    if not os.path.exists(APPS_FILE):
        default_apps = [
            {
                "id": "APP-1001",
                "applicant_name": "Alexander Vance",
                "email": "alexander.v@example.com",
                "person_age": 34,
                "person_income": 95000,
                "person_emp_length": 7.5,
                "person_home_ownership": "MORTGAGE",
                "loan_amnt": 12000,
                "loan_intent": "HOMEIMPROVEMENT",
                "loan_grade": "A",
                "loan_int_rate": 7.5,
                "credit_score": 760,
                "cb_person_default_on_file": "N",
                "cb_person_cred_hist_length": 9,
                "submitted_at": "2026-10-31 10:15",
                "status": "Pending Review",
                "terms_accepted": True,
                "terms_accepted_at": "2026-10-31 10:14",
                "lender_decision": None,
                "lender_notes": None,
                "approved_rate": None
            },
            {
                "id": "APP-1002",
                "applicant_name": "Elena Rostova",
                "email": "elena.r@example.com",
                "person_age": 29,
                "person_income": 48000,
                "person_emp_length": 3.0,
                "person_home_ownership": "RENT",
                "loan_amnt": 15000,
                "loan_intent": "MEDICAL",
                "loan_grade": "C",
                "loan_int_rate": 13.2,
                "credit_score": 645,
                "cb_person_default_on_file": "N",
                "cb_person_cred_hist_length": 5,
                "submitted_at": "2026-11-01 14:30",
                "status": "Pending Review",
                "terms_accepted": True,
                "terms_accepted_at": "2026-11-01 14:28",
                "lender_decision": None,
                "lender_notes": None,
                "approved_rate": None
            },
            {
                "id": "APP-1003",
                "applicant_name": "Marcus Sterling",
                "email": "marcus.s@example.com",
                "person_age": 26,
                "person_income": 28000,
                "person_emp_length": 1.2,
                "person_home_ownership": "RENT",
                "loan_amnt": 20000,
                "loan_intent": "DEBTCONSOLIDATION",
                "loan_grade": "E",
                "loan_int_rate": 18.9,
                "credit_score": 520,
                "cb_person_default_on_file": "Y",
                "cb_person_cred_hist_length": 3,
                "submitted_at": "2026-11-02 09:45",
                "status": "Pending Review",
                "terms_accepted": True,
                "terms_accepted_at": "2026-11-02 09:44",
                "lender_decision": None,
                "lender_notes": None,
                "approved_rate": None
            },
            {
                "id": "APP-1004",
                "applicant_name": "Samantha Chen",
                "email": "samantha.c@example.com",
                "person_age": 38,
                "person_income": 115000,
                "person_emp_length": 9.0,
                "person_home_ownership": "OWN",
                "loan_amnt": 25000,
                "loan_intent": "VENTURE",
                "loan_grade": "A",
                "loan_int_rate": 6.8,
                "credit_score": 790,
                "cb_person_default_on_file": "N",
                "cb_person_cred_hist_length": 12,
                "submitted_at": "2026-10-28 16:20",
                "status": "Approved",
                "terms_accepted": True,
                "terms_accepted_at": "2026-10-28 16:18",
                "lender_decision": "Approved",
                "lender_notes": "Exceptional FICO score with verified assets and low debt-to-income margin.",
                "approved_rate": 6.8
            }
        ]
        with open(APPS_FILE, 'w') as f:
            json.dump(default_apps, f, indent=2)

init_applications_store()

def get_applications():
    if os.path.exists(APPS_FILE):
        with open(APPS_FILE, 'r') as f:
            return json.load(f)
    return []

def save_applications(apps):
    with open(APPS_FILE, 'w') as f:
        json.dump(apps, f, indent=2)

def evaluate_applicant_ml(data, model_choice='random_forest'):
    """Evaluates applicant against trained Scikit-learn models"""
    age = float(data.get('person_age', 30))
    income = float(data.get('person_income', 50000))
    emp_length = float(data.get('person_emp_length', PREPROCESSOR_META['emp_median']))
    home_ownership = str(data.get('person_home_ownership', 'RENT')).upper()
    loan_intent = str(data.get('loan_intent', 'PERSONAL')).upper()
    loan_grade = str(data.get('loan_grade', 'B')).upper()
    loan_amnt = float(data.get('loan_amnt', 10000))
    loan_int_rate = float(data.get('loan_int_rate', PREPROCESSOR_META['rate_median']))
    default_on_file = str(data.get('cb_person_default_on_file', 'N')).upper()
    cred_hist_length = float(data.get('cb_person_cred_hist_length', 5))
    credit_score = float(data.get('credit_score', 650))
    
    loan_percent_income = round(loan_amnt / max(income, 1), 2)
    
    row_dict = {col: 0 for col in PREPROCESSOR_META['feature_cols']}
    row_dict['person_age'] = age
    row_dict['person_income'] = income
    row_dict['person_emp_length'] = emp_length
    row_dict['loan_amnt'] = loan_amnt
    row_dict['loan_int_rate'] = loan_int_rate
    row_dict['loan_percent_income'] = loan_percent_income
    row_dict['cb_person_cred_hist_length'] = cred_hist_length
    row_dict['credit_score'] = credit_score
    
    home_col = f"person_home_ownership_{home_ownership}"
    if home_col in row_dict:
        row_dict[home_col] = 1
        
    intent_col = f"loan_intent_{loan_intent}"
    if intent_col in row_dict:
        row_dict[intent_col] = 1
        
    grade_col = f"loan_grade_{loan_grade}"
    if grade_col in row_dict:
        row_dict[grade_col] = 1
        
    default_col = f"cb_person_default_on_file_{default_col if default_on_file in ['N', 'Y'] else 'N'}"
    if default_col in row_dict:
        row_dict[default_col] = 1
        
    input_df = pd.DataFrame([row_dict])[PREPROCESSOR_META['feature_cols']]
    
    if model_choice not in MODELS:
        model_choice = 'random_forest'
    model = MODELS[model_choice]
    
    if model_choice == 'logistic_regression':
        input_processed = SCALER.transform(input_df)
    else:
        input_processed = input_df
        
    probs = model.predict_proba(input_processed)[0]
    prob_default = float(probs[1])
    default_pct = round(prob_default * 100, 1)
    
    if prob_default < 0.35:
        risk_category = 'Low Risk'
        risk_color = '#10b981'
        badge_class = 'badge-low'
        recommendation = 'Eligible for Standard Approval'
        suggested_rate = max(5.5, round(loan_int_rate, 1))
        action_plan = 'Applicant demonstrates favorable repayment probability and healthy debt-to-income margin. Standard interest rate tier applies.'
    elif prob_default < 0.65:
        risk_category = 'Medium Risk'
        risk_color = '#f59e0b'
        badge_class = 'badge-medium'
        recommendation = 'Conditional Approval / Underwriter Review'
        suggested_rate = round(loan_int_rate + 2.5, 1)
        action_plan = 'Borderline credit profile. Recommend secondary review of bank cashflows, request additional proof of income, or require collateral.'
    else:
        risk_category = 'High Risk'
        risk_color = '#ef4444'
        badge_class = 'badge-high'
        recommendation = 'High Default Risk / Decline or Require Guarantor'
        suggested_rate = round(loan_int_rate + 5.0, 1)
        action_plan = 'Applicant exhibits high probability of default. Recommend decline unless backed by prime guarantor and liquid collateral.'
        
    risk_drivers = []
    if loan_percent_income > 0.30:
        risk_drivers.append(f"Elevated Debt Burden: Requested loan is {int(loan_percent_income*100)}% of annual income.")
    if credit_score < 620:
        risk_drivers.append(f"Subprime Credit Score: FICO {int(credit_score)} is below standard lending threshold (670+).")
    if default_on_file == 'Y':
        risk_drivers.append("Adverse History: Prior default record significantly increases statistical risk.")
    if loan_int_rate > 15.0:
        risk_drivers.append(f"High Interest Exposure: Rate of {loan_int_rate:.1f}% creates heavy compounding burden.")
    if emp_length < 2.0:
        risk_drivers.append(f"Short Employment Tenure: {emp_length:.1f} years indicates potential income fluctuation.")
        
    if not risk_drivers:
        risk_drivers.append("Optimal financial indicators across credit history, income, and debt ratio.")
        
    return {
        'model_used': METRICS_DATA['models'][model_choice]['name'],
        'default_probability': default_pct,
        'non_default_probability': round((1 - prob_default) * 100, 1),
        'risk_category': risk_category,
        'risk_color': risk_color,
        'badge_class': badge_class,
        'recommendation': recommendation,
        'action_plan': action_plan,
        'suggested_rate': suggested_rate,
        'loan_percent_income': loan_percent_income,
        'risk_drivers': risk_drivers
    }

@app.route('/')
def home():
    return render_template(
        'index.html',
        metrics=METRICS_DATA,
        meta=PREPROCESSOR_META
    )

@app.route('/api/applications', methods=['GET'])
def list_applications():
    return jsonify(get_applications())

@app.route('/api/applications', methods=['POST'])
def submit_application():
    try:
        data = request.get_json(force=True)
        
        # Verify Terms & Conditions acceptance
        if not data.get('terms_accepted', False):
            return jsonify({
                'success': False,
                'error': 'You must review and accept the Lender Terms & Conditions before submitting.'
            }), 400
            
        apps = get_applications()
        new_id = f"APP-{1000 + len(apps) + 1}"
        
        income = float(data.get('person_income', 50000))
        loan_amnt = float(data.get('loan_amnt', 10000))
        credit_score = float(data.get('credit_score', 650))
        
        # Auto-assign initial grade & rate
        dti = loan_amnt / max(income, 1)
        grade_score = credit_score - (dti * 250)
        if grade_score >= 680:
            loan_grade = 'A'
            base_rate = 7.2
        elif grade_score >= 620:
            loan_grade = 'B'
            base_rate = 10.5
        elif grade_score >= 560:
            loan_grade = 'C'
            base_rate = 13.4
        elif grade_score >= 500:
            loan_grade = 'D'
            base_rate = 16.2
        elif grade_score >= 440:
            loan_grade = 'E'
            base_rate = 18.8
        else:
            loan_grade = 'F'
            base_rate = 21.5
            
        new_app = {
            "id": new_id,
            "applicant_name": str(data.get('applicant_name', 'Anonymous Applicant')),
            "email": str(data.get('email', 'applicant@example.com')),
            "person_age": int(data.get('person_age', 30)),
            "person_income": income,
            "person_emp_length": float(data.get('person_emp_length', 3.0)),
            "person_home_ownership": str(data.get('person_home_ownership', 'RENT')).upper(),
            "loan_amnt": loan_amnt,
            "loan_intent": str(data.get('loan_intent', 'PERSONAL')).upper(),
            "loan_grade": loan_grade,
            "loan_int_rate": base_rate,
            "credit_score": credit_score,
            "cb_person_default_on_file": str(data.get('cb_person_default_on_file', 'N')).upper(),
            "cb_person_cred_hist_length": int(data.get('cb_person_cred_hist_length', 5)),
            "submitted_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "status": "Pending Review",
            "terms_accepted": True,
            "terms_accepted_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "lender_decision": None,
            "lender_notes": None,
            "approved_rate": None
        }
        
        apps.insert(0, new_app)
        save_applications(apps)
        
        return jsonify({
            'success': True,
            'message': 'Application submitted successfully with Terms & Conditions acknowledged.',
            'application': new_app
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/applications/<app_id>/decision', methods=['POST'])
def record_lender_decision(app_id):
    try:
        data = request.get_json(force=True)
        decision = data.get('decision') # 'Approved', 'Conditional', 'Declined'
        notes = data.get('notes', '')
        rate = data.get('approved_rate')
        
        apps = get_applications()
        updated = False
        target_app = None
        
        for a in apps:
            if a['id'] == app_id:
                a['status'] = decision
                a['lender_decision'] = decision
                a['lender_notes'] = notes
                if rate:
                    a['approved_rate'] = float(rate)
                updated = True
                target_app = a
                break
                
        if not updated:
            return jsonify({'success': False, 'error': 'Application not found'}), 404
            
        save_applications(apps)
        return jsonify({'success': True, 'application': target_app})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/predict', methods=['POST'])
def predict_risk():
    try:
        data = request.get_json(force=True)
        model_choice = data.get('model_type', 'random_forest')
        result = evaluate_applicant_ml(data, model_choice)
        return jsonify({'success': True, **result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    return jsonify(METRICS_DATA)

@app.route('/api/dataset-sample', methods=['GET'])
def get_dataset_sample():
    sample_file = os.path.join(STATIC_DATA_DIR, 'dataset_sample.json')
    if os.path.exists(sample_file):
        with open(sample_file, 'r') as f:
            sample_data = json.load(f)
        return jsonify(sample_data)
    return jsonify([])

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
